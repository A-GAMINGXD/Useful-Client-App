function show(id){
document.querySelectorAll('.page').forEach(p=>p.style.display='none');
document.getElementById(id).style.display='block';
}

function toggleTheme(){
document.body.classList.toggle('light');
}

function genPass(){
let chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
let p="";for(let i=0;i<20;i++)p+=chars[Math.floor(Math.random()*chars.length)];
passOut.innerText=p;
}

function saveNotes(){
localStorage.setItem('notes',notesBox.value);
}

window.onload=()=>{notesBox.value=localStorage.getItem('notes')||"";}

function doCalc(){
try{calcOut.innerText=eval(calcInput.value);}catch{calcOut.innerText='Error';}
}

function addImages(){
let f=imgUpload.files;
for(let i=0;i<f.length;i++){
let r=new FileReader();
r.onload=e=>{
let img=document.createElement('img');img.src=e.target.result;imgs.appendChild(img);
}
r.readAsDataURL(f[i]);
}
}

let files={};

function createFile(){
let n=fname.value;
let c=fcontent.value;
if(!n)return;
files[n]=c;
renderList();
}

function renderList(){
fileList.innerHTML="";
Object.keys(files).forEach(name=>{
let p=document.createElement('p');
p.innerText=name;
p.onclick=()=>{fname.value=name;fcontent.value=files[name];}
fileList.appendChild(p);
});
}

function runCode(){
let name=fname.value;
let c=fcontent.value;

if(name.endsWith('.js')){
let frame=runner;
frame.src="data:text/html,<script>"+encodeURIComponent(c)+"<\/script>";
}
else if(name.endsWith('.html')){
runner.src="data:text/html,"+encodeURIComponent(c);
}
else if(name.endsWith('.css')){
runner.src="data:text/html,<style>"+encodeURIComponent(c)+"</style><p>CSS Loaded</p>";
}
else if(name.endsWith('.json')){
try{JSON.parse(c);alert('Valid JSON');}catch{showErr('Sorry ERROR This Is Not Valid Code');}
}
else{
showErr('Sorry ERROR This Is Not Valid Code');
}
}

function showErr(t){errText.innerText=t;errorBox.style.display='block';}
function closeErr(){errorBox.style.display='none';}
